"""Adapters Module"""
